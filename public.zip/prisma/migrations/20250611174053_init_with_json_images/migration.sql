/*
  Warnings:

  - You are about to drop the column `fbxUrl` on the `Project` table. All the data in the column will be lost.
  - You are about to drop the column `imageUrl` on the `Project` table. All the data in the column will be lost.
  - Added the required column `imageUrls` to the `Project` table without a default value. This is not possible if the table is not empty.

*/
-- RedefineTables
PRAGMA defer_foreign_keys=ON;
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_Project" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "title" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "location" TEXT,
    "lod" INTEGER,
    "sow" TEXT,
    "projectType" TEXT,
    "area" INTEGER,
    "imageUrls" TEXT NOT NULL,
    "softwareUsed" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
);
INSERT INTO "new_Project" ("area", "createdAt", "description", "id", "location", "lod", "projectType", "softwareUsed", "sow", "title", "updatedAt") SELECT "area", "createdAt", "description", "id", "location", "lod", "projectType", "softwareUsed", "sow", "title", "updatedAt" FROM "Project";
DROP TABLE "Project";
ALTER TABLE "new_Project" RENAME TO "Project";
PRAGMA foreign_keys=ON;
PRAGMA defer_foreign_keys=OFF;
