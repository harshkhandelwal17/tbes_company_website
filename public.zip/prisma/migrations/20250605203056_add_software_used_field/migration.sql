-- AlterTable
ALTER TABLE "Project" ADD COLUMN "softwareUsed" TEXT;
