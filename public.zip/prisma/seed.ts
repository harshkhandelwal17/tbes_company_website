import { PrismaClient } from '@prisma/client'
import bcrypt from 'bcrypt'

const prisma = new PrismaClient()

async function main() {
  const password = await bcrypt.hash('admin123', 10) // CHANGE this password

  await prisma.admin.upsert({
    where: { email: 'admin@tbesglobal.com' },
    update: {},
    create: {
      email: 'admin@tbesglobal.com',
      password,
    },
  })

  console.log('Admin created.')
}

main()
  .catch(e => {
    console.error(e)
    process.exit(1)
  })
  .finally(() => {
    prisma.$disconnect()
  })
