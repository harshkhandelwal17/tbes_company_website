import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'

export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl

  const isLoggedIn = request.cookies.get('admin-auth')?.value === 'true'
  const protectedPaths = ['/admin', '/admin/career', '/admin/projects']
  const isProtected = protectedPaths.some(path =>
    pathname.startsWith(path)
  )

  // Example: Redirect root path to default locale (optional)
  if (pathname === '/') {
    const locale = request.headers.get('accept-language')?.startsWith('it')
      ? 'it'
      : request.headers.get('accept-language')?.startsWith('fr')
      ? 'fr'
      : 'en'
    return NextResponse.redirect(new URL(`/${locale}`, request.url))
  }

  // 🔒 Admin route protection
  if (isProtected && !isLoggedIn) {
    return NextResponse.redirect(new URL('/admin/login', request.url))
  }

  return NextResponse.next()
}
