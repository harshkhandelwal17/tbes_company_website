'use client';

import Link from 'next/link';
import { ArrowRight, Building, Zap, Users, CheckCircle, Star, DollarSign, Award, Headphones } from 'lucide-react';
import { useState, useEffect, useRef } from 'react';

export default function HomePage() {
  const services = [
    {
      icon: Building,
      title: 'BIM Modeling',
      description: 'Advanced 3D building information modeling for architectural and structural projects.'
    },
    {
      icon: Zap,
      title: 'CAD Services',
      description: 'Comprehensive CAD drafting and design services for construction projects.'
    },
    {
      icon: Users,
      title: 'Consulting',
      description: 'Expert consultation on BIM implementation and project optimization.'
    }
  ];

  const stats = [
    { number: '200+', label: 'Projects Completed' },
    { number: '50+', label: 'Happy Clients' },
    { number: '6+', label: 'Years Experience' },
    { number: '24/7', label: 'Support Available' }
  ];

  const whyChooseUs = [
    {
      icon: DollarSign,
      title: 'Cost Effective',
      description: 'Our optimized and cost effective way drives us in reaching the milestones within time and budgets',
      color: 'text-pink-500'
    },
    {
      icon: Award,
      title: 'Quality',
      description: 'Our commitment towards excellence & quality is driven by our team of experienced professionals',
      color: 'text-cyan-500'
    },
    {
      icon: Headphones,
      title: 'Support',
      description: 'Adding value to engineering & providing technical support is our mission that drives us for the future',
      color: 'text-green-500'
    }
  ];

  // Contact Form State
  const [form, setForm] = useState({ 
    name: '', 
    email: '', 
    subject: '', 
    message: '' 
  });
  const [status, setStatus] = useState('');

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus('Sending...');

    try {
      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });

      if (res.ok) {
        setStatus('Message sent successfully!');
        setForm({ name: '', email: '', subject: '', message: '' });
        // Clear status after 3 seconds
        setTimeout(() => setStatus(''), 3000);
      } else {
        setStatus('Failed to send message. Please try again.');
      }
    } catch (error) {
      setStatus('An error occurred. Please try again.');
    }
  };

  // Fixed AnimatedTestimonials Component
const AnimatedTestimonials = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isClient, setIsClient] = useState(false); // Add client-side flag
  const sectionRef = useRef<HTMLElement>(null);

  interface Testimonial {
    text: string;
    author: string;
    role: string;
    rating: number;
  }

  const testimonials: Testimonial[] = [
    {
      text: "Good job on the project with very little errors!!! Thank you very much and wish your team all the best",
      author: "K M",
      role: "",
      rating: 5
    },
    {
      text: "I am impressed with the work. It looks better than I thought it could be!!! I definitely look forward to work with the team in the future",
      author: "B H",
      role: "",
      rating: 5
    },
    {
      text: "Great progress. Thank you guys for the dedicated effort!",
      author: "R E",
      role: "",
      rating: 4
    },
    {
      text: "Great work by the team. Keep it up guys!",
      author: " C J",
      role: "",
      rating: 5
    },
    {
      text: "Good job team. It is really impressive to work with the team!",
      author: " T H",
      role: "",
      rating: 4
    }
  ];

  // Set client-side flag
  useEffect(() => {
    setIsClient(true);
  }, []);

  useEffect(() => {
    if (!isClient) return; // Only run on client-side

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.3 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, [isClient]);

  useEffect(() => {
    if (!isVisible || !isClient) return; // Only run on client-side when visible

    const interval = setInterval(() => {
      setCurrentIndex((prevIndex) => (prevIndex + 1) % testimonials.length);
    }, 4000);

    return () => clearInterval(interval);
  }, [isVisible, testimonials.length, isClient]);

  const renderStars = (rating: number) => {
    return Array.from({ length: rating }, (_, i) => (
      <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
    ));
  };

  // Don't render anything until client-side hydration is complete
  if (!isClient) {
    return (
      <section className="bg-black text-white py-20 overflow-hidden">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              What Our Clients Say
            </h2>
            <div className="w-24 h-1 bg-gradient-to-r from-blue-400 to-purple-500 mx-auto"></div>
          </div>
          <div className="relative h-80 md:h-64 flex items-center justify-center">
            <div className="text-gray-400">Loading testimonials...</div>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section ref={sectionRef} className="bg-black text-white py-20 overflow-hidden">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h2 className={`text-4xl md:text-5xl font-bold mb-4 transition-all duration-1000 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}>
            What Our Clients Say
          </h2>
          <div className={`w-24 h-1 bg-gradient-to-r from-blue-400 to-purple-500 mx-auto transition-all duration-1000 delay-300 ${
            isVisible ? 'opacity-100 scale-x-100' : 'opacity-0 scale-x-0'
          }`}></div>
        </div>

        {/* Testimonials Container */}
        <div className="relative h-80 md:h-64">
          {testimonials.map((testimonial, index) => {
            const isActive = index === currentIndex;
            const isPrev = index === (currentIndex - 1 + testimonials.length) % testimonials.length;
            const isNext = index === (currentIndex + 1) % testimonials.length;
            
            let translateX = '100%';
            let opacity = 0;
            let scale = 0.8;
            
            if (isActive) {
              translateX = '0%';
              opacity = 1;
              scale = 1;
            } else if (isPrev) {
              translateX = '-100%';
              opacity = 0.3;
              scale = 0.9;
            } else if (isNext) {
              translateX = '100%';
              opacity = 0.3;
              scale = 0.9;
            }

            return (
              <div
                key={index}
                className={`absolute inset-0 flex items-center justify-center transition-all duration-700 ease-in-out transform ${
                  isVisible ? '' : 'translate-x-full opacity-0'
                }`}
                style={{
                  transform: `translateX(${translateX}) scale(${scale})`,
                  opacity: isVisible ? opacity : 0,
                  transitionDelay: isVisible ? '0ms' : `${index * 200}ms`
                }}
              >
                <div className="max-w-4xl mx-auto text-center px-4">
                  <div className="mb-8">
                    <CheckCircle className="w-16 h-16 text-green-400 mx-auto mb-6 animate-pulse" />
                    
                    {/* Stars */}
                    <div className="flex justify-center mb-6 space-x-1">
                      {renderStars(testimonial.rating)}
                    </div>
                    
                    {/* Quote */}
                    <blockquote className="text-xl md:text-2xl lg:text-3xl font-light mb-6 italic leading-relaxed">
                      "{testimonial.text}"
                    </blockquote>
                    
                    {/* Author */}
                    <cite className="text-lg md:text-xl font-semibold text-gray-300">
                      - {testimonial.author} {testimonial.role}
                    </cite>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Pagination Dots - Add suppressHydrationWarning */}
        <div className={`flex justify-center space-x-3 mt-12 transition-all duration-1000 delay-700 ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
        }`}>
          {testimonials.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentIndex(index)}
              className={`w-3 h-3 rounded-full transition-all duration-300 ${
                index === currentIndex
                  ? 'bg-white scale-125'
                  : 'bg-gray-600 hover:bg-gray-400'
              }`}
              suppressHydrationWarning={true}
            />
          ))}
        </div>

        {/* Navigation Arrows - Add suppressHydrationWarning */}
        <div className={`flex justify-center space-x-8 mt-8 transition-all duration-1000 delay-900 ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
        }`}>
          <button
            onClick={() => setCurrentIndex((currentIndex - 1 + testimonials.length) % testimonials.length)}
            className="w-12 h-12 rounded-full bg-gray-800 hover:bg-gray-700 transition-colors duration-300 flex items-center justify-center group"
            suppressHydrationWarning={true}
          >
            <svg className="w-6 h-6 text-gray-300 group-hover:text-white transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>
          <button
            onClick={() => setCurrentIndex((currentIndex + 1) % testimonials.length)}
            className="w-12 h-12 rounded-full bg-gray-800 hover:bg-gray-700 transition-colors duration-300 flex items-center justify-center group"
            suppressHydrationWarning={true}
          >
            <svg className="w-6 h-6 text-gray-300 group-hover:text-white transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </button>
        </div>

        {/* Floating Elements */}
        <div className="absolute top-10 left-10 w-20 h-20 bg-gradient-to-r from-blue-500/10 to-purple-500/10 rounded-full animate-pulse"></div>
        <div className="absolute bottom-10 right-10 w-32 h-32 bg-gradient-to-r from-purple-500/5 to-pink-500/5 rounded-full animate-pulse delay-1000"></div>
      </div>
    </section>
  );
};

  return (
    <div className="min-h-screen">
      {/* Enhanced Hero Section with Construction Theme */}
      <section className="relative bg-gradient-to-br from-slate-900 via-gray-900 to-slate-800 text-white overflow-hidden min-h-screen flex items-center">
        {/* Construction-themed Background Elements */}
        <div className="absolute inset-0">
          {/* Blueprint Grid Lines */}
          <div className="absolute inset-0 opacity-20">
            <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
              <defs>
                <pattern id="blueprint-grid" width="10" height="10" patternUnits="userSpaceOnUse">
                  <path d="M 10 0 L 0 0 0 10" fill="none" stroke="#60a5fa" strokeWidth="0.5"/>
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#blueprint-grid)" />
            </svg>
          </div>

          {/* Floating Construction Elements */}
          <div className="absolute top-20 left-10 w-32 h-32 bg-gradient-to-r from-orange-500/20 to-yellow-500/20 rounded-lg rotate-12 animate-pulse"></div>
          <div className="absolute top-40 right-20 w-24 h-24 bg-gradient-to-r from-blue-500/15 to-cyan-500/15 animate-bounce" style={{animationDelay: '1s'}}>
            {/* Building Block Shape */}
            <div className="w-full h-full bg-gradient-to-br from-blue-400/30 to-blue-600/30 relative">
              <div className="absolute top-2 left-2 w-4 h-4 bg-blue-300/50 rounded"></div>
              <div className="absolute top-2 right-2 w-4 h-4 bg-blue-300/50 rounded"></div>
              <div className="absolute bottom-2 left-2 w-4 h-4 bg-blue-300/50 rounded"></div>
              <div className="absolute bottom-2 right-2 w-4 h-4 bg-blue-300/50 rounded"></div>
            </div>
          </div>
          
          {/* Engineering Tools */}
          <div className="absolute bottom-40 left-20 w-16 h-16 animate-spin" style={{animationDuration: '12s'}}>
            <svg viewBox="0 0 64 64" className="w-full h-full text-orange-400/30">
              <circle cx="32" cy="32" r="28" fill="none" stroke="currentColor" strokeWidth="3"/>
              <circle cx="32" cy="32" r="4" fill="currentColor"/>
              <line x1="32" y1="4" x2="32" y2="12" stroke="currentColor" strokeWidth="2"/>
              <line x1="32" y1="52" x2="32" y2="60" stroke="currentColor" strokeWidth="2"/>
              <line x1="4" y1="32" x2="12" y2="32" stroke="currentColor" strokeWidth="2"/>
              <line x1="52" y1="32" x2="60" y2="32" stroke="currentColor" strokeWidth="2"/>
            </svg>
          </div>
          
          {/* 3D Cube representing BIM modeling */}
          <div className="absolute bottom-20 right-40 w-40 h-40 animate-pulse" style={{animationDelay: '2s'}}>
            <div className="relative w-full h-full transform-gpu" style={{
              transform: 'rotateX(15deg) rotateY(15deg)',
              animation: 'float 6s ease-in-out infinite'
            }}>
              {/* Front face */}
              <div className="absolute inset-0 bg-gradient-to-br from-purple-500/20 to-blue-500/20 border border-purple-400/30"></div>
              {/* Top face */}
              <div className="absolute inset-0 bg-gradient-to-br from-blue-400/15 to-cyan-400/15 border border-blue-400/30" 
                   style={{transform: 'rotateX(90deg) translateZ(20px)'}}></div>
              {/* Right face */}
              <div className="absolute inset-0 bg-gradient-to-br from-cyan-400/10 to-teal-400/10 border border-cyan-400/30" 
                   style={{transform: 'rotateY(90deg) translateZ(20px)'}}></div>
            </div>
          </div>
          
          {/* Structural beam elements */}
          <div className="absolute top-1/3 left-1/4 w-2 h-32 bg-gradient-to-b from-gray-400/20 to-gray-600/20 animate-pulse" style={{animationDelay: '0.5s'}}></div>
          <div className="absolute top-1/2 right-1/3 w-2 h-40 bg-gradient-to-b from-gray-400/20 to-gray-600/20 animate-pulse" style={{animationDelay: '1.5s'}}></div>
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <h1 className="text-4xl md:text-6xl font-bold leading-tight">
                <span className="inline-block opacity-0 animate-[slideInLeft_0.8s_ease-out_0.2s_forwards]">We</span>{' '}
                <span className="inline-block opacity-0 animate-[slideInLeft_0.8s_ease-out_0.4s_forwards]">believe</span>{' '}
                <span className="inline-block opacity-0 animate-[slideInLeft_0.8s_ease-out_0.6s_forwards]">virtual</span>{' '}
                <span className="inline-block opacity-0 animate-[slideInLeft_0.8s_ease-out_0.8s_forwards]">reality</span>{' '}
                <span className="inline-block opacity-0 animate-[slideInLeft_0.8s_ease-out_1s_forwards]">is</span>{' '}
                <span className="inline-block opacity-0 animate-[slideInLeft_0.8s_ease-out_1.2s_forwards]">the</span>
                <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-400 via-yellow-400 to-orange-500 inline-block opacity-0 animate-[slideInUp_1s_ease-out_1.4s_forwards] relative">
                  future of construction
                  <div className="absolute -bottom-2 left-0 w-full h-1 bg-gradient-to-r from-orange-400 to-yellow-400 transform scale-x-0 animate-[expandWidth_0.8s_ease-out_2.2s_forwards]"></div>
                </span>{' '}
                <span className="inline-block opacity-0 animate-[slideInRight_0.8s_ease-out_1.6s_forwards]">industry</span>
              </h1>
              
              <p className="text-xl text-gray-200 opacity-0 animate-[fadeInUp_1s_ease-out_1.8s_forwards]">
                Our optimized and cost-effective approach drives us to reach milestones 
                within time and budgets, delivering excellence through our experienced team.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 opacity-0 animate-[fadeInUp_1s_ease-out_2s_forwards]">
                <Link 
                  href="/services"
                  className="group bg-gradient-to-r from-orange-500 to-yellow-500 hover:from-orange-600 hover:to-yellow-600 text-white px-8 py-3 rounded-lg font-semibold transition-all duration-300 inline-flex items-center justify-center transform hover:scale-105 hover:shadow-2xl"
                >
                  Our Services
                  <ArrowRight className="ml-2 group-hover:translate-x-1 transition-transform" size={20} />
                </Link>
                <Link 
                  href="/projects"
                  className="group border-2 border-orange-400 text-orange-400 hover:text-white px-8 py-3 rounded-lg font-semibold hover:bg-gradient-to-r hover:from-orange-500 hover:to-yellow-500 hover:border-transparent transition-all duration-300 inline-flex items-center justify-center transform hover:scale-105"
                >
                  View Projects
                  <ArrowRight className="ml-2 group-hover:translate-x-1 transition-transform" size={20} />
                </Link>
              </div>
            </div>
            
            <div className="lg:text-right opacity-0 animate-[fadeInRight_1s_ease-out_2.2s_forwards]">
              <div className="relative bg-white/10 backdrop-blur-sm rounded-2xl p-8 border border-white/20 hover:bg-white/15 transition-all duration-500 group">
                {/* Animated Corner Elements */}
                <div className="absolute -top-4 -right-4 w-8 h-8 bg-gradient-to-r from-gray-400 to-gray-500 rounded-full animate-bounce"></div>
                
                <div className="text-center">
                  <div className="relative w-20 h-20 bg-gradient-to-r from-gray-500 to--500 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300">
                    <Building size={40} className="text-white animate-pulse" />
                    
                    {/* Construction-themed rotating elements */}
                    <div className="absolute inset-0 border-2 border-transparent border-t-orange-400 border-r-yellow-400 rounded-full animate-spin" style={{animationDuration: '3s'}}></div>
                    <div className="absolute -inset-2 border border-orange-300/30 rounded-full animate-ping" style={{animationDuration: '2s'}}></div>
                  </div>
                  
                  <h3 className="text-2xl font-bold mb-2 group-hover:text-orange-300 transition-colors">BIM Excellence</h3>
                  <p className="text-gray-200 group-hover:text-gray-100 transition-colors">
                    Leading provider of innovative Building Information Modeling solutions
                  </p>
                </div>
                
                {/* Enhanced Glowing Border Effect */}
                <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-orange-500/20 via-yellow-500/20 to-orange-500/20 opacity-0 group-hover:opacity-100 transition-opacity duration-500 -z-10 blur-xl"></div>
              </div>
            </div>
          </div>
        </div>

        {/* Animated Construction Particles */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          {[...Array(15)].map((_, i) => (
            <div
              key={i}
              className="absolute animate-float opacity-30"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 5}s`,
                animationDuration: `${4 + Math.random() * 6}s`
              }}
            >
              {i % 3 === 0 ? (
                // Blueprint symbols
                <div className="w-2 h-2 border border-blue-400/50 rotate-45"></div>
              ) : i % 3 === 1 ? (
                // Construction dots
                <div className="w-1 h-1 bg-orange-400/60 rounded-full"></div>
              ) : (
                // Structural elements
                <div className="w-3 h-1 bg-gray-400/40"></div>
              )}
            </div>
          ))}
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 opacity-0 animate-[fadeIn_1s_ease-out_3s_forwards]">
          <div className="flex flex-col items-center text-white/60">
            <span className="text-sm mb-2">Scroll Down</span>
            <div className="w-6 h-10 border-2 border-white/30 rounded-full flex justify-center">
              <div className="w-1 h-3 bg-white/60 rounded-full mt-2 animate-bounce"></div>
            </div>
          </div>
        </div>
      </section>

      {/* Add required CSS animations */}
      <style jsx>{`
        @keyframes slideInLeft {
          from {
            opacity: 0;
            transform: translateX(-50px);
          }
          to {
            opacity: 1;
            transform: translateX(0);
          }
        }

        @keyframes slideInRight {
          from {
            opacity: 0;
            transform: translateX(50px);
          }
          to {
            opacity: 1;
            transform: translateX(0);
          }
        }

        @keyframes slideInUp {
          from {
            opacity: 0;
            transform: translateY(30px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        @keyframes fadeInUp {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        @keyframes fadeInRight {
          from {
            opacity: 0;
            transform: translateX(30px);
          }
          to {
            opacity: 1;
            transform: translateX(0);
          }
        }

        @keyframes fadeIn {
          from {
            opacity: 0;
          }
          to {
            opacity: 1;
          }
        }

        @keyframes expandWidth {
          from {
            transform: scaleX(0);
          }
          to {
            transform: scaleX(1);
          }
        }

        @keyframes float {
          0%, 100% {
            transform: rotateX(15deg) rotateY(15deg) translateY(0px);
          }
          50% {
            transform: rotateX(15deg) rotateY(15deg) translateY(-10px);
          }
        }
      `}</style>

      {/* Stats Section */}
      <section className="bg-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-4xl font-bold text-black mb-2">{stat.number}</div>
                <div className="text-gray-600">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="bg-gray-50 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-700 mb-6">Why Choose Us ?</h2>
            <p className="text-lg text-gray-500 max-w-4xl mx-auto leading-relaxed">
              TBES Global is a leading BIM & CAD services company providing innovative Building 
              Information Modeling (BIM) solutions for architects, engineers, contractors, sub-contractors 
              and consultants around the globe
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {whyChooseUs.map((item, index) => {
              const IconComponent = item.icon;
              return (
                <div key={index} className="text-center group">
                  <div className="mb-8">
                    <div className={`w-20 h-20 ${item.color} mx-auto mb-6 flex items-center justify-center rounded-full bg-white shadow-lg group-hover:scale-110 transition-transform duration-300`}>
                      <IconComponent size={40} />
                    </div>
                  </div>
                  <h3 className="text-2xl font-bold text-gray-800 mb-4">{item.title}</h3>
                  <p className="text-gray-600 leading-relaxed max-w-sm mx-auto">
                    {item.description}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* We are TBES Global Section */}
      <section className="bg-black py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-8">We are TBES Global</h2>
          </div>
          
          <div className="max-w-5xl mx-auto">
            <div className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-2xl p-8 md:p-12 shadow-xl border border-gray-700">
              <div className="space-y-6 text-gray-300 leading-relaxed">
                <p className="text-lg md:text-xl">
                  <strong className="text-white">TBES Global Private Limited</strong> is a leading BIM and CAD service provider in the field of Architecture, Engineering and Construction industry worldwide.
                </p>
                
                <p className="text-lg md:text-xl">
                  Building Information Modeling (BIM) has been the biggest technological development that has helped the AEC industry in creating a complete construction environment on a virtual platform. This has been the greatest tool for project planning, design collaboration and coordination, asset management, risk analysis, resource planning and last but not the least cost optimization.
                </p>
                
                <p className="text-lg md:text-xl">
                  BIM implementation has helped us in recognizing and rectification of potential problems before the construction hits the real ground.
                </p>
                
                <p className="text-lg md:text-xl">
                  We TBES Global are the grass root level players in the design and construction industry collaborating in the BIM solutions, implementation and executing projects of different scalability.
                </p>
                
                <div className="mt-8 pt-6 border-t border-gray-600">
                  <p className="text-xl md:text-2xl font-semibold text-center text-white">
                    To collaborate with us feel free to get in touch at{' '}
                    <a 
                      href="mailto:info@tbesglobal.com" 
                      className="text-yellow-400 hover:text-yellow-300 transition-colors underline decoration-2 underline-offset-2"
                    >
                      info@tbesglobal.com
                    </a>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Preview */}
      <section className="bg-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Our Core Services</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Adding value to engineering & providing technical support is our mission 
              that drives us for the future
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {services.map((service, index) => {
              const IconComponent = service.icon;
              return (
                <div key={index} className="bg-gray-50 rounded-xl p-8 shadow-lg hover:shadow-xl transition-shadow">
                  <div className="w-16 h-16 bg-gray-100 rounded-lg flex items-center justify-center mb-6">
                    <IconComponent className="text-black" size={32} />
                  </div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-4">{service.title}</h3>
                  <p className="text-gray-600 mb-6">{service.description}</p>
                  <Link 
                    href="/services"
                    className="text-black font-semibold hover:text-gray-700 inline-flex items-center"
                  >
                    Learn More
                    <ArrowRight className="ml-1" size={16} />
                  </Link>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Animated Testimonial Section */}
      <AnimatedTestimonials />

      {/* CTA Section */}
      <section className="bg-white py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-gray-900 mb-6">
            Ready to Start Your Next Project?
          </h2>
          <p className="text-xl text-gray-600 mb-8">
            Our commitment towards excellence & quality is driven by our team 
            of experienced professionals
          </p>
          <Link 
            href="/contact"
            className="bg-black text-white px-8 py-4 rounded-lg font-semibold hover:bg-gray-800 transition-colors inline-flex items-center text-lg"
          >
            Get Started Today
            <ArrowRight className="ml-2" size={20} />
          </Link>
        </div>
      </section>

     {/* Contact Section */}
      <section className="relative bg-gradient-to-br from-gray-900 via-gray-800 to-black text-white py-20 overflow-hidden">
        {/* Background Image Overlay */}
        <div className="absolute inset-0 bg-black/60"></div>
        
        {/* Mountain/Background Pattern */}
        <div className="absolute inset-0 opacity-20">
          <svg className="w-full h-full" viewBox="0 0 1920 1080" fill="none">
            <path d="M0 1080L480 540L960 720L1440 360L1920 540V1080H0Z" fill="url(#mountain-gradient)" />
            <defs>
              <linearGradient id="mountain-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#374151" />
                <stop offset="100%" stopColor="#1f2937" />
              </linearGradient>
            </defs>
          </svg>
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
            
            {/* Left Side - Contact Information */}
            <div className="space-y-12">
              <div>
                <h2 className="text-4xl md:text-5xl font-bold mb-8 text-white">
                  Get in Touch
                </h2>
              </div>

              {/* Find us at the office */}
              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <div className="w-8 h-8 mt-1 flex-shrink-0">
                    <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/>
                    </svg>
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold text-white mb-3">Find us at the office</h3>
                    <p className="text-gray-300 text-lg leading-relaxed">
                      Benachity, Durgapur, West Bengal,<br />
                      India, Pin - 713213
                    </p>
                  </div>
                </div>
              </div>

              {/* Give us a ring */}
              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <div className="w-8 h-8 mt-1 flex-shrink-0">
                    <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/>
                    </svg>
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold text-white mb-3">Give us a ring</h3>
                    <p className="text-gray-300 text-lg mb-2">+91 629 479 6582</p>
                    <p className="text-gray-400 text-base">Mon - Fri, 10:00-20:00</p>
                  </div>
                </div>
              </div>
            </div>

            
            {/* Right Side - Contact Form */}
            <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 border border-white/20">
              <div className="bg-orange-500 text-white text-center py-4 rounded-t-lg mb-8 -m-8 mb-8">
                <h3 className="text-2xl font-bold">Contact Us</h3>
              </div>
              
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <input
                      type="text"
                      name="name"
                      value={form.name}
                      onChange={handleChange}
                      placeholder="Your Name"
                      required
                      className="w-full px-4 py-3 rounded-lg bg-white/10 border border-white/20 text-white placeholder-gray-300 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent transition-all"
                    />
                  </div>
                  <div>
                    <input
                      type="email"
                      name="email"
                      value={form.email}
                      onChange={handleChange}
                      placeholder="Your Email"
                      required
                      className="w-full px-4 py-3 rounded-lg bg-white/10 border border-white/20 text-white placeholder-gray-300 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent transition-all"
                    />
                  </div>
                </div>
                
                <div>
                  <input
                    type="text"
                    name="subject"
                    value={form.subject}
                    onChange={handleChange}
                    placeholder="Subject"
                    required
                    className="w-full px-4 py-3 rounded-lg bg-white/10 border border-white/20 text-white placeholder-gray-300 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent transition-all"
                  />
                </div>
                
                <div>
                  <textarea
                    name="message"
                    value={form.message}
                    onChange={handleChange}
                    rows={6}
                    placeholder="Your Message"
                    required
                    className="w-full px-4 py-3 rounded-lg bg-white/10 border border-white/20 text-white placeholder-gray-300 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent transition-all resize-none"
                  ></textarea>
                </div>
                
                <div className="text-center">
                  <button
                    type="submit"
                    disabled={status === 'Sending...'}
                    className="bg-orange-500 hover:bg-orange-600 disabled:bg-orange-400 disabled:cursor-not-allowed text-white font-bold py-4 px-8 rounded-lg transition-colors duration-300 text-lg shadow-lg hover:shadow-xl transform hover:scale-105 disabled:transform-none"
                  >
                    {status === 'Sending...' ? 'SENDING...' : 'SEND MESSAGE'}
                  </button>
                </div>
                
                {/* Status Message */}
                {status && (
                  <div className={`text-center mt-4 p-3 rounded-lg ${
                    status.includes('success') 
                      ? 'bg-green-500/20 text-green-300 border border-green-500/30' 
                      : status.includes('Failed') || status.includes('error')
                      ? 'bg-red-500/20 text-red-300 border border-red-500/30'
                      : 'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                  }`}>
                    {status}
                  </div>
                )}
              </form>
            </div>
          </div>
        </div>

        
        {/* Decorative Elements */}
        <div className="absolute top-20 right-20 w-32 h-32 bg-gradient-to-r from-orange-500/10 to-yellow-500/10 rounded-full animate-pulse"></div>
        <div className="absolute bottom-20 left-20 w-24 h-24 bg-gradient-to-r from-blue-500/10 to-purple-500/10 rounded-full animate-pulse delay-1000"></div>
      </section>
    </div>
    
  );
}