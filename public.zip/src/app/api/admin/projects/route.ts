import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import fs from 'fs';
import path from 'path';

// Ensure upload directories exist
function ensureUploadDirs() {
  const imageDir = path.join(process.cwd(), 'public/uploads/images');
  
  if (!fs.existsSync(imageDir)) {
    fs.mkdirSync(imageDir, { recursive: true });
  }
}

// POST - Create new project
export async function POST(req: NextRequest) {
  try {
    console.log('POST request received');
    ensureUploadDirs();
    
    const formData = await req.formData();
    console.log('FormData keys:', Array.from(formData.keys()));
    
    const title = formData.get('title') as string;
    const description = formData.get('description') as string;
    const location = formData.get('location') as string;
    const lodStr = formData.get('lod') as string;
    const sow = formData.get('sow') as string;
    const projectType = formData.get('projectType') as string;
    const areaStr = formData.get('area') as string;
    const softwareUsed = formData.get('softwareUsed') as string;
    
    // Debug form data
    console.log('Form data received:', {
      title,
      description,
      location,
      lodStr,
      sow,
      projectType,
      areaStr,
      softwareUsed
    });
    
    // Validate and parse numbers
    const lod = parseInt(lodStr);
    const area = parseInt(areaStr);
    
    if (isNaN(lod) || isNaN(area)) {
      return NextResponse.json(
        { error: 'LOD and Area must be valid numbers' },
        { status: 400 }
      );
    }
    
    // Handle multiple image files
    const imageFiles = formData.getAll('images') as File[];
    
    console.log('Images received:', imageFiles.map(file => file.name));
    
    if (!imageFiles || imageFiles.length === 0) {
      return NextResponse.json(
        { error: 'At least one image is required' },
        { status: 400 }
      );
    }

    // Save all image files
    const imageUrls: string[] = [];
    for (const imageFile of imageFiles) {
      if (imageFile && imageFile.size > 0) {
        const imageBuffer = Buffer.from(await imageFile.arrayBuffer());
        const imageFileName = `${Date.now()}-${Math.random().toString(36).substring(7)}-${imageFile.name}`;
        const imagePath = path.join(process.cwd(), 'public/uploads/images', imageFileName);
        fs.writeFileSync(imagePath, imageBuffer);
        imageUrls.push(`/uploads/images/${imageFileName}`);
        console.log('Image saved:', imagePath);
      }
    }

    if (imageUrls.length === 0) {
      return NextResponse.json(
        { error: 'No valid images were uploaded' },
        { status: 400 }
      );
    }

    // Prepare data for database - Fix field names to match Prisma schema
    const projectData = {
      title,
      description,
      location,
      lod,
      sow,
      projectType,
      area,
      imageUrl: JSON.stringify(imageUrls), // Changed from imageUrls to imageUrl
      softwareUsed,
    };
    
    console.log('Creating project with data:', projectData);

    // Create project in database
    const project = await prisma.project.create({
      data: projectData,
    });

    // Parse imageUrl back to array for response
    const projectResponse = {
      ...project,
      imageUrls: JSON.parse(project.imageUrl) // Convert back to imageUrls for response
    };

    console.log('Project created successfully:', projectResponse);
    return NextResponse.json(projectResponse);
  } catch (error) {
    console.error('Detailed error creating project:', error);
    
    // More specific error handling
    if (error instanceof Error) {
      return NextResponse.json(
        { 
          error: 'Failed to create project',
          details: error.message,
          stack: process.env.NODE_ENV === 'development' ? error.stack : undefined
        },
        { status: 500 }
      );
    }
    
    return NextResponse.json(
      { error: 'Unknown error occurred' },
      { status: 500 }
    );
  }
}

// PUT - Update existing project
export async function PUT(req: NextRequest) {
  try {
    console.log('PUT request received');
    ensureUploadDirs();
    
    const formData = await req.formData();
    console.log('FormData keys:', Array.from(formData.keys()));
    
    const idStr = formData.get('id') as string;
    const title = formData.get('title') as string;
    const description = formData.get('description') as string;
    const location = formData.get('location') as string;
    const lodStr = formData.get('lod') as string;
    const sow = formData.get('sow') as string;
    const projectType = formData.get('projectType') as string;
    const areaStr = formData.get('area') as string;
    const softwareUsed = formData.get('softwareUsed') as string;
    console.log('Update data received:', {
      idStr,
      title,
      description,
      location,
      lodStr,
      sow,
      projectType,
      areaStr,
      softwareUsed
    });
    
    if (!idStr) {
      return NextResponse.json(
        { error: 'Project ID is required' },
        { status: 400 }
      );
    }
    
    // Convert id to number
    const id = parseInt(idStr);
    if (isNaN(id)) {
      return NextResponse.json(
        { error: 'Project ID must be a valid number' },
        { status: 400 }
      );
    }
    
    // Validate and parse numbers
    const lod = parseInt(lodStr);
    const area = parseInt(areaStr);
    
    if (isNaN(lod) || isNaN(area)) {
      return NextResponse.json(
        { error: 'LOD and Area must be valid numbers' },
        { status: 400 }
      );
    }
    
    // Handle multiple image files (optional for updates)
    const imageFiles = formData.getAll('images') as File[];
    const replaceImages = formData.get('replaceImages') === 'true'; // Flag to determine if we should replace all images

    console.log('Files for update:', {
      images: imageFiles.map(file => file.name),
      replaceImages
    });

    // Get existing project
    console.log('Looking for project with ID:', id);
    const existingProject = await prisma.project.findUnique({
      where: { id }
    });

    if (!existingProject) {
      console.log('Project not found with ID:', id);
      return NextResponse.json(
        { error: 'Project not found' },
        { status: 404 }
      );
    }

    console.log('Found existing project:', existingProject);

    // Parse existing imageUrls from JSON string
    let imageUrls: string[] = [];
    try {
      imageUrls = JSON.parse(existingProject.imageUrl || '[]');
    } catch (e) {
      console.error('Error parsing existing imageUrls:', e);
      imageUrls = [];
    }

    // Handle image updates
    if (imageFiles && imageFiles.length > 0 && imageFiles.some(file => file.size > 0)) {
      if (replaceImages) {
        // Delete old images if replacing all
        for (const oldImageUrl of imageUrls) {
          const oldImagePath = path.join(process.cwd(), 'public', oldImageUrl);
          if (fs.existsSync(oldImagePath)) {
            fs.unlinkSync(oldImagePath);
            console.log('Old image deleted:', oldImagePath);
          }
        }
        imageUrls = [];
      }

      // Save new images
      for (const imageFile of imageFiles) {
        if (imageFile && imageFile.size > 0) {
          const imageBuffer = Buffer.from(await imageFile.arrayBuffer());
          const imageFileName = `${Date.now()}-${Math.random().toString(36).substring(7)}-${imageFile.name}`;
          const imagePath = path.join(process.cwd(), 'public/uploads/images', imageFileName);
          fs.writeFileSync(imagePath, imageBuffer);
          imageUrls.push(`/uploads/images/${imageFileName}`);
          console.log('New image saved:', imagePath);
        }
      }
    }

    // Prepare update data - Fix field names to match Prisma schema
    const updateData = {
      title,
      description,
      location,
      lod,
      sow,
      projectType,
      area,
      imageUrl: JSON.stringify(imageUrls), // Changed from imageUrls to imageUrl
      softwareUsed,
    };
    
    console.log('Updating project with data:', updateData);

    // Update project in database
    const project = await prisma.project.update({
      where: { id },
      data: updateData,
    });

    // Parse imageUrl back to array for response
    const projectResponse = {
      ...project,
      imageUrls: JSON.parse(project.imageUrl) // Convert back to imageUrls for response
    };

    console.log('Project updated successfully:', projectResponse);
    return NextResponse.json(projectResponse);
  } catch (error) {
    console.error('Detailed error updating project:', error);
    
    if (error instanceof Error) {
      return NextResponse.json(
        { 
          error: 'Failed to update project',
          details: error.message,
          stack: process.env.NODE_ENV === 'development' ? error.stack : undefined
        },
        { status: 500 }
      );
    }
    
    return NextResponse.json(
      { error: 'Unknown error occurred' },
      { status: 500 }
    );
  }
}

// DELETE - Delete project
export async function DELETE(req: NextRequest) {
  try {
    console.log('DELETE request received');
    const { searchParams } = new URL(req.url);
    const idStr = searchParams.get('id');

    console.log('Delete request for ID:', idStr);

    if (!idStr) {
      return NextResponse.json(
        { error: 'Project ID is required' },
        { status: 400 }
      );
    }

    // Convert id to number
    const id = parseInt(idStr);
    if (isNaN(id)) {
      return NextResponse.json(
        { error: 'Project ID must be a valid number' },
        { status: 400 }
      );
    }

    // Get project to delete files
    const project = await prisma.project.findUnique({
      where: { id }
    });

    if (!project) {
      console.log('Project not found for deletion:', id);
      return NextResponse.json(
        { error: 'Project not found' },
        { status: 404 }
      );
    }

    console.log('Found project for deletion:', project);

    // Parse and delete all image files
    try {
      const imageUrls = JSON.parse(project.imageUrl || '[]');
      for (const imageUrl of imageUrls) {
        const imagePath = path.join(process.cwd(), 'public', imageUrl);
        if (fs.existsSync(imagePath)) {
          fs.unlinkSync(imagePath);
          console.log('Image file deleted:', imagePath);
        }
      }
    } catch (e) {
      console.error('Error parsing imageUrls for deletion:', e);
    }

    // Delete from database
    await prisma.project.delete({
      where: { id }
    });

    console.log('Project deleted successfully from database');
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Detailed error deleting project:', error);
    
    if (error instanceof Error) {
      return NextResponse.json(
        { 
          error: 'Failed to delete project',
          details: error.message,
          stack: process.env.NODE_ENV === 'development' ? error.stack : undefined
        },
        { status: 500 }
      );
    }
    
    return NextResponse.json(
      { error: 'Unknown error occurred' },
      { status: 500 }
    );
  }
}