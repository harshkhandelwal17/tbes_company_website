export default function ProjectsPage() {
  return <h2>Welcome To Admin Panel</h2>;
}