// app/admin/layout.tsx

import Link from "next/link";

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div style={{ display: "flex", height: "100vh" }}>
      <aside
        style={{
          width: "220px",
          background: "#111",
          color: "#fff",
          padding: "1.5rem",
        }}
      >
        <h2 style={{ marginBottom: "2rem" }}>Admin Panel</h2>
        <nav style={{ display: "flex", flexDirection: "column", gap: "1rem" }}>
          <Link href="/admin" style={{ color: "#ccc" }}>🏠 Dashboard</Link>
          <Link href="/admin/career" style={{ color: "#ccc" }}>💼 Career</Link>
          <Link href="/admin/projects" style={{ color: "#ccc" }}>🖼️ Projects</Link>
          <Link href="/admin/logout" style={{ color: "#ccc" }}>🚪 Logout</Link>
        </nav>
      </aside>
      <main style={{ flex: 1, padding: "2rem" }}>{children}</main>
    </div>
  );
}
