'use client'

import { useState } from 'react'

export default function ContactForm() {
  const [form, setForm] = useState({ name: '', email: '', message: '' })
  const [status, setStatus] = useState('')

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setStatus('Sending...')

    const res = await fetch('/api/contact', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form),
    })

    if (res.ok) {
      setStatus('Message sent!')
      setForm({ name: '', email: '', message: '' })
    } else {
      setStatus('Failed to send.')
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-800 overflow-hidden">
      {/* Floating Background Elements */}
      <div className="fixed inset-0 pointer-events-none">
        <div className="absolute top-1/4 left-1/12 w-20 h-20 bg-white bg-opacity-10 rounded-full animate-pulse"></div>
        <div className="absolute top-3/5 right-1/12 w-32 h-32 bg-white bg-opacity-10 rounded-full animate-pulse delay-1000"></div>
        
      </div>

      <div className="max-w-6xl mx-auto px-4 py-8 relative z-10">
        {/* Header */}
        <div className="text-center mb-12 animate-fade-in">
          <h1 className="text-5xl font-bold text-white mb-4 drop-shadow-lg">Get In Touch</h1>
          <p className="text-xl text-white text-opacity-90 font-light">Ready to transform your construction projects with BIM technology?</p>
        </div>

        {/* Main Grid */}
        <div className="grid lg:grid-cols-2 gap-8 mb-12">
          {/* Contact Form Card */}
          <div className="bg-white bg-opacity-95 backdrop-blur-xl rounded-3xl p-8 shadow-2xl border border-white border-opacity-20 transform hover:-translate-y-2 transition-all duration-300">
            <h2 className="text-2xl font-bold text-black mb-6 flex items-center gap-3">
              <span className="w-8 h-8 bg-gradient-to-r from-gray-800 to-black rounded-full flex items-center justify-center text-white text-sm">📧</span>
              Send Us a Message
            </h2>
            
            <div onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-4">
                <div className="transform transition-all duration-200 hover:-translate-y-1">
                  <label className="block text-sm font-semibold text-black mb-2">Your Name</label>
                  <input
                    name="name"
                    value={form.name}
                    onChange={handleChange}
                    placeholder="Your Name"
                    className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:border-black focus:ring-4 focus:ring-gray-200 transition-all duration-200 text-black bg-white"
                    required
                  />
                </div>

                <div className="transform transition-all duration-200 hover:-translate-y-1">
                  <label className="block text-sm font-semibold text-black mb-2">Email Address</label>
                  <input
                    name="email"
                    type="email"
                    value={form.email}
                    onChange={handleChange}
                    placeholder="Your Email"
                    className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:border-black focus:ring-4 focus:ring-gray-200 transition-all duration-200 text-black bg-white"
                    required
                  />
                </div>

                <div className="transform transition-all duration-200 hover:-translate-y-1">
                  <label className="block text-sm font-semibold text-black mb-2">Your Message</label>
                  <textarea
                    name="message"
                    value={form.message}
                    onChange={handleChange}
                    placeholder="Your Message"
                    rows={5}
                    className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:border-black focus:ring-4 focus:ring-gray-200 transition-all duration-200 text-black bg-white resize-vertical"
                    required
                  />
                </div>
              </div>

              <button
                onClick={handleSubmit}
                className="w-full bg-gradient-to-r from-gray-800 to-black text-white font-semibold py-4 px-6 rounded-xl hover:from-gray-900 hover:to-gray-800 transform hover:-translate-y-1 hover:shadow-xl transition-all duration-200 focus:ring-4 focus:ring-gray-300"
              >
                Send
              </button>
              
              {status && (
                <p className={`text-center font-medium ${
                  status === 'Message sent!' ? 'text-green-600' : 
                  status === 'Failed to send.' ? 'text-red-600' : 'text-gray-600'
                }`}>
                  {status}
                </p>
                              )}
            </div>
          </div>

          {/* Contact Information Card */}
          <div className="bg-white bg-opacity-95 backdrop-blur-xl rounded-3xl p-8 shadow-2xl border border-white border-opacity-20 transform hover:-translate-y-2 transition-all duration-300">
            <h2 className="text-2xl font-bold text-black mb-6 flex items-center gap-3">
              <span className="w-8 h-8 bg-gradient-to-r from-gray-800 to-black rounded-full flex items-center justify-center text-white text-sm">📍</span>
              Contact Information
            </h2>
            
            <div className="space-y-4">
              {[
                { icon: '📧', title: 'Email', content: 'info@tbesglobal.com' },
                { icon: '📞', title: 'Phone', content: '+91 629-479-6582' },
                { icon: '🏢', title: 'Location', content: 'Durgapur, West Bengal, India' },
                { icon: '🕒', title: 'Business Hours', content: 'Mon - Fri: 9:00 AM - 7:00 PM IST' },
                { icon: '🌐', title: 'Global Reach', content: 'Serving clients worldwide' }
              ].map((item, index) => (
                <div key={index} className="flex items-center gap-4 p-4 bg-gray-100 rounded-xl hover:bg-gray-200 transform hover:translate-x-2 transition-all duration-200">
                  <div className="w-12 h-12 bg-gradient-to-r from-gray-800 to-black rounded-full flex items-center justify-center text-white text-lg flex-shrink-0">
                    {item.icon}
                  </div>
                  <div>
                    <h3 className="font-semibold text-black text-lg">{item.title}</h3>
                    <p className="text-gray-700">{item.content}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Company Information Card */}
        <div className="bg-white bg-opacity-95 backdrop-blur-xl rounded-3xl p-8 shadow-2xl border border-white border-opacity-20 text-center">
          <h2 className="text-2xl font-bold text-black mb-4">TBES Global - The BIM Engineering Studio</h2>
          <p className="text-gray-700 leading-relaxed mb-6">
            We are an innovative Building Information Modeling (BIM) solutions and services provider for architects, engineers, contractors, 
            sub-contractors and consultants around the globe. Established in 2018, we specialize in providing collaborative and coordinated 
            design support that helps deliver exceptional results for our clients.
          </p>
          <div className="flex flex-wrap justify-center gap-3">
            {['BIM Modeling', 'CAD Services', 'Point Cloud', '3D Rendering', 'Architecture', 'Engineering', 'Construction'].map((tag, index) => (
              <span key={index} className="bg-gradient-to-r from-gray-800 to-black text-white px-4 py-2 rounded-full text-sm font-medium">
                {tag}
              </span>
            ))}
          </div>
        </div>
      </div>

      <style jsx>{`
        @keyframes fade-in {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        .animate-fade-in {
          animation: fade-in 1s ease-out;
        }
      `}</style>
    </div>
  )
}