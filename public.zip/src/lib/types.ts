export type Dictionary = {
  home: {
    welcome: string
    description: string
  }
}
